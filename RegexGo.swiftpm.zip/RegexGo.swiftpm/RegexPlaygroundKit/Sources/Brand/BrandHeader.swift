//
//  BrandHeader.swift
//  
//
//  Created by Chu Yong on 4/15/23.
//

import SwiftUI

struct BrandHeader: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct BrandHeader_Previews: PreviewProvider {
    static var previews: some View {
        BrandHeader()
    }
}
